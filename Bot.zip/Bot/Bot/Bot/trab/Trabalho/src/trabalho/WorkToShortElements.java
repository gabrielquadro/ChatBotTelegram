package trabalho;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

public class WorkToShortElements
{

	private static Scanner sc;

	private static final int quantidade = 10500;

	private static int interator = 0;

	private static ArrayList<Integer> Randomnumbers;

	static int[] vetor = new int[quantidade];

	public static void main(String[] args)
	{
		sc = new Scanner(System.in);
		long tempoInicial;
		long tempoFinal;
		int x;

		// Gerar os números para ordenação de forma randômica
		Randomnumbers = new ArrayList<Integer>();
		Random randomGenerator = new Random();
		int random = 0;
		while (Randomnumbers.size() < quantidade)
		{
			random = randomGenerator.nextInt(quantidade);
			if (!Randomnumbers.contains(random))
			{
				Randomnumbers.add(random);
			}
		}

		// Passar os números gerados para o vetor
		immputWithOutOrder();

		System.out.println("Elementos do vetor desordenados => " + Arrays.toString(vetor));

		System.out.println("\n------------Menu de seleção_------------");
		System.out.println("1 - Ordenação por seleção");
		System.out.println("2 - Ordenação por insetção");
		System.out.println("3 - Ordenação por intercalação");
		System.out.println("4 - Ordenação por sepraração");
		System.out.println("5 - SAIR!");
		System.out.print("Resposta: ");
		x = sc.nextInt();
		while (x != 0)
		{
			switch (x)
			{
				case 1:
					tempoInicial = System.currentTimeMillis();
					/*
					 * objetivo : passar sempre o menor valor para a primeira posição (dependendo da
					 * ordem requerida pode ser o maior valor). Então, para que isso seja feito ele percorre
					 * todos os elementos procurando um menor valor para só então colocá-lo na primeira posição,
					 * repetindo essa tarefa para cada um dos elementos.
					 */
					selectionSort(vetor);
					tempoFinal = System.currentTimeMillis();
					System.out.println("Elementos do vetor ordenados => " + Arrays.toString(vetor));
					System.out.println("Executado em = " + (tempoFinal - tempoInicial) + " ms");
					System.out.println("\n");
					// Passar os números gerados para o vetor - DESORDENA NOVAMENTE
					immputWithOutOrder();
					break;
				case 2:
					tempoInicial = System.currentTimeMillis();

					insertionSort(vetor);

					tempoFinal = System.currentTimeMillis();

					System.out.println("Elementos do vetor ordenados => " + Arrays.toString(vetor));
					System.out.println("Executado em = " + (tempoFinal - tempoInicial) + " ms");
					System.out.println("\n");
					// Passar os números gerados para o vetor - DESORDENA NOVAMENTE
					immputWithOutOrder();
					break;
				case 3:

					tempoInicial = System.currentTimeMillis();

					int[] w = new int[vetor.length];

					mergesort(vetor, w, 0, vetor.length - 1);

					tempoFinal = System.currentTimeMillis();

					System.out.println("Elementos do vetor ordenados => " + Arrays.toString(vetor));
					System.out.println("Executado em = " + (tempoFinal - tempoInicial) + " ms");
					System.out.println("\n");
					// Passar os números gerados para o vetor - DESORDENA NOVAMENTE
					immputWithOutOrder();

					break;
				case 4:
					tempoInicial = System.currentTimeMillis();

					quickSort(vetor, 0, vetor.length - 1);

					tempoFinal = System.currentTimeMillis();

					System.out.println("Elementos do vetor ordenados => " + Arrays.toString(vetor));
					System.out.println("Executado em = " + (tempoFinal - tempoInicial) + " ms");
					System.out.println("\n");
					// Passar os números gerados para o vetor - DESORDENA NOVAMENTE
					immputWithOutOrder();
					break;
				case 5:
					System.out.println("\n\nAté mais!\n\n");
					sc.close();
					System.exit(0);
					break;
				default:
					System.out.println("Opção inválida!");
					break;
			}

			System.out.println("Elementos do vetor desordenados => " + Arrays.toString(vetor));

			System.out.println("------------Menu----------------");
			System.out.println("1 - Ordenação por seleção");
			System.out.println("2 - Ordenação por inserção");
			System.out.println("3 - Ordenação por intercalação");
			System.out.println("4 - Ordenação por sepraração");
			System.out.println("5 - SAIR!");
			System.out.print("Resposta: ");
			x = sc.nextInt();
		}

	}

	public static void immputWithOutOrder()
	{
		for (Integer numRandom : Randomnumbers)
		{
			vetor[interator] = numRandom.intValue();
			interator++;
		}
		interator = 0;
	}

	// seleção
	public static void selectionSort(int[] array)
	{ // ordenação por seleção
		for (int fixo = 0; fixo < array.length - 1; fixo++)
		{ // percorre o vetor
			int menor = fixo; // guarda a posição do menor elemento na variável “menor”
			// a variável menor, que na primeira iteração é igual ao primeiro elemento do vetor

			// percorremos (através de outro laço for) todos os elementos do array partindo do segundo elemento até o último
			for (int i = menor + 1; i < array.length; i++)
			{ // percorre o array procurando por um valor menor
				if (array[i] < array[menor])
				{ // compara se o valor na posição percorrida pelo for é menor que o da posição menor
					menor = i; // atualiza o valor de menor
				}
			}
			if (menor != fixo)
			{ // checa se a posição do menor elemento é diferente da posição atual
				int t = array[fixo];
				array[fixo] = array[menor]; // então é feita uma troca de valores, colocando o menor elemento na frente.
				array[menor] = t;
			}
		}

	}

	// inserção
	public static void insertionSort(int[] vetor)
	{
		int j;
		int key;
		int i;
		for (j = 1; j < vetor.length; j++)
		{
			key = vetor[j];
			for (i = j - 1; (i >= 0) && (vetor[i] > key); i--)
			{
				vetor[i + 1] = vetor[i];
			}
			vetor[i + 1] = key;
		}
	}

	// quicksort - separação
	private static void quickSort(int[] vetor, int inicio, int fim)
	{
		if (inicio < fim)
		{
			int posicaoPivo = separar(vetor, inicio, fim);
			quickSort(vetor, inicio, posicaoPivo - 1);
			quickSort(vetor, posicaoPivo + 1, fim);
		}
	}

	private static int separar(int[] vetor, int inicio, int fim)
	{
		int pivo = vetor[inicio];
		int i = inicio + 1, f = fim;
		while (i <= f)
		{
			if (vetor[i] <= pivo)
			{
				i++;
			}
			else if (pivo < vetor[f])
			{
				f--;
			}
			else
			{
				int troca = vetor[i];
				vetor[i] = vetor[f];
				vetor[f] = troca;
				i++;
				f--;
			}
		}
		vetor[inicio] = vetor[f];
		vetor[f] = pivo;
		return f;
	}

	// merge sort - intercalação
	private static void mergesort(int[] vetor, int[] w, int ini, int fim)
	{
		if (ini < fim)
		{
			int meio = (ini + fim) / 2;
			mergesort(vetor, w, ini, meio);
			mergesort(vetor, w, meio + 1, fim);
			intercalar(vetor, w, ini, meio, fim);
		}

	}

	private static void intercalar(int[] vetor, int[] w, int ini, int meio, int fim)
	{
		for (int k = ini; k <= fim; k++)
			// Vamos criar uma cópia do vetor para W.
			w[k] = vetor[k];

		// Vai andar na primeira metade do vetor
		int i = ini;
		// Vai andar da metade para o final
		int j = meio + 1;

		for (int k = ini; k <= fim; k++)
		{
			if (i > meio)
			{
				vetor[k] = w[j++];
			}
			else if (j > fim)
			{
				vetor[k] = w[i++];
			}
			else if (w[i] < w[j])
			{
				vetor[k] = w[i++];
			}
			else
			{
				vetor[k] = w[j++];
			}
		}
	}

}
