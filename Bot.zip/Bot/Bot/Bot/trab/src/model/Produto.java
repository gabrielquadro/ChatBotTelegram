package model;

public class Produto {
    private int idProduto;
    private float preco;
    private int categoria_idCategoria;
    private String descricao;
    public Produto() {
    }

    public Produto(String descricao, float preco, int categoria_idCategoria) {
        this.descricao = descricao;
        this.preco = preco;
        this.categoria_idCategoria = categoria_idCategoria;
    }


    public int getIdProduto() {
        return idProduto;
    }

    public void setIdProduto(int idProduto) {
        this.idProduto = idProduto;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public double getPreco() {
        return preco;
    }

    public void setPreco(float preco) {
        this.preco = preco;
    }

    public int getCategoria_idCategoria() {
        return categoria_idCategoria;
    }

    public void setCategoria_idCategoria(int categoria_idCategoria) {
        this.categoria_idCategoria = categoria_idCategoria;
    }    
}
