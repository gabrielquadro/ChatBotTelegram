package model;

import Bot.*;
import dal.DAO;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

public class BotThread extends Thread {

    private Bot b;
    private DAO<Cliente> clienteDAO;
    private RecorteInformacoes infos;
    private Cliente cliente;
    private ArrayList<DialagoThread> lstResp;
    private ArrayList lst;
    private DialagoThread rspt;

    public BotThread() throws ClassNotFoundException, SQLException {
        this.b = new Bot("663985030:AAExe7ZxYdMI-oItOKab6NU_mC_bV6TTelk"); // token do meu bot
        this.clienteDAO = new DAO<Cliente>();
        this.lstResp = new ArrayList<DialagoThread>();
        this.lst = new ArrayList();
    }

    public void run() {
        try {
            //Alocação dos clientes na lista para procurar se os clientes estão no banco de dados
            lst = clienteDAO.todosRegistros(Cliente.class, 0, 0);
            Cliente auxCli = new Cliente();

            for (int i = 0; i < lst.size(); i++) {
                auxCli = (Cliente) lst.get(i);
                DialagoThread rsp = new DialagoThread(auxCli.getIdCliente(), auxCli.getNomeCliente());
                lstResp.add(rsp);
            }

            //recepção de mensagens
            while (true) {

                //recebe mensagem
                infos = b.recebeMensagem();

                //mensagem recebida
                if (infos != null) {

                    try {
                        //Criação do cliente
                        cliente = clienteDAO.consultaCliente(infos.getUser_id());

                        //Consulta se o cliente ja existe
                        if (cliente == null) {//Se ainda não existe
                            //Cria o novo cliente e ja insere no banco de dados
                            cliente = new Cliente();
                            cliente.setIdCliente(infos.getUser_id());
                            cliente.setNomeCliente(infos.getNome());
                            clienteDAO.inserir(cliente);
                            //diálago
                            try {
                                //Manda a mensagem inicial para um novo contato
                                rspt = new DialagoThread(infos);
                                try {
                                    rspt.responder(infos, b);
                                } catch (ParseException ex) {
                                    Logger.getLogger(BotThread.class.getName()).log(Level.SEVERE, null, ex);
                                }
                                lstResp.add(rspt); // lista de threads

                            } catch (ClassNotFoundException ex) {
                                Logger.getLogger(BotThread.class.getName()).log(Level.SEVERE, null, ex);
                            }

                        } else {//Se ja existe
                            //Recebe a lista de clientes no banco de dados para procurar em qual trhead esta sendo tratado
                            lst = clienteDAO.todosRegistros(Cliente.class, 0, 0);

                            //For para localizar a Trhead do cliente
                            for (int i = 0; i < lst.size(); i++) {
                                //Testa se o id do cliente é o mesmo da Trhead encontrada
                                if (infos.getUser_id() == lstResp.get(i).getCliId()) {
                                    try {
                                        //Responde o cliente
                                        lstResp.get(i).responder(infos, b);
                                    } catch (ParseException ex) {
                                        Logger.getLogger(BotThread.class.getName()).log(Level.SEVERE, null, ex);
                                    }
                                }
                            }
                        }

                    } catch (SQLException ex) {
                        Logger.getLogger(BotThread.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }

            }
        } catch (SQLException ex) {
            Logger.getLogger(BotThread.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
