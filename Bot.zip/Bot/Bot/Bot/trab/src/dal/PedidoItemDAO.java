
package dal;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import model.Categoria;
import model.Pedido;
import model.PedidoItem;

public class PedidoItemDAO {
    public ArrayList<PedidoItem> consultar() throws SQLException, ClassNotFoundException {
        ArrayList<PedidoItem> lstRet = new ArrayList<>();
        Conexao conn = new Conexao();
        //faz a consulta no BD
        String sql = "SELECT * FROM pedido_item";

        PreparedStatement st = conn.prepareStatement(sql);
        ResultSet rs = st.executeQuery();
        while (rs.next()) {
            PedidoItem l = new PedidoItem();
            l.setProduto_id(rs.getInt("produto_id"));
            l.setPedido_id(rs.getInt("pedido_id"));
            l.setQuantidade(rs.getInt("quantidade"));
            l.setPreco(rs.getDouble("preco"));
            l.setObservacao(rs.getString("observacao"));
            lstRet.add(l);
        }
        st.close();
        rs.close();
        return lstRet; //retorna uma lista com as categoeias existentes no banco de dados
    }
     public ArrayList<Pedido> consultarPedido(int id) throws SQLException, ClassNotFoundException {
        ArrayList<Pedido> lstRet = new ArrayList<>();
        Conexao conn = new Conexao();
        //faz a consulta no BD
        String sql = "SELECT * FROM pedido where id = ?";

        PreparedStatement st = conn.prepareStatement(sql);
        st.setInt(1, id);
        ResultSet rs = st.executeQuery();
        while (rs.next()) {
            Pedido l = new Pedido();
            l.setCliente_idCliente(rs.getInt("cliente_id"));
            l.setData(rs.getTimestamp("data"));
            l.setEntregue(rs.getInt("entregue"));
            lstRet.add(l);
        }
        st.close();
        rs.close();
        return lstRet; //retorna uma lista com as categoeias existentes no banco de dados
    }
}
