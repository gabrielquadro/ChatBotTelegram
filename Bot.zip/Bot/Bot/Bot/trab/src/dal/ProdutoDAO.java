package dal;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import model.Categoria;
import model.Pedido;
import model.PedidoItem;
import model.Produto;

public class ProdutoDAO {

    public boolean inserir(Produto a) throws SQLException, ClassNotFoundException {
        Conexao conn = new Conexao();
        PreparedStatement st = conn.prepareStatement("insert into produto(descricao, preco, categoria_id) values (? , ? , ? ) ");
        st.setString(1, a.getDescricao());
        st.setFloat(2, (float) a.getPreco());
        st.setInt(3, a.getCategoria_idCategoria());

        int ret = st.executeUpdate();
        if (ret > 0) {
            return true;//significa que inseriu corretamente
        } else {
            return false;//significa que não inseriu
        }
    }

    public ArrayList<Produto> consultar() throws SQLException, ClassNotFoundException {
        ArrayList<Produto> lstRet = new ArrayList<>();
        Conexao conn = new Conexao();
        //faz a consulta no BD
        String sql = "SELECT * FROM produto";

        PreparedStatement st = conn.prepareStatement(sql);
        ResultSet rs = st.executeQuery();
        while (rs.next()) {//enquanto tiver registros no ResultSet
            Produto l = new Produto();

            l.setIdProduto(rs.getInt("id"));
            l.setDescricao(rs.getString("descricao"));
            l.setPreco(rs.getFloat("preco"));
            l.setCategoria_idCategoria(rs.getInt("categoria_id"));

            lstRet.add(l);
        }
        st.close();
        rs.close();
        return lstRet;
    }

    
     public int TemProd(int idprod) throws ClassNotFoundException, SQLException{
         ArrayList<PedidoItem> lstpedido = new ArrayList<>(); //carrega os produto
        Conexao conn = new Conexao();
        //consulta pra ve se nehum produto ta ligado a categoria que quer excluir
        String sql = "SELECT * FROM pedido_item where produto_id = ?";

        PreparedStatement st = conn.prepareStatement(sql);
        st.setInt(1, idprod);
        ResultSet rs = st.executeQuery();
        while (rs.next()) {
            PedidoItem l = new PedidoItem();

            l.setPedido_id(rs.getInt("pedido_id"));
            l.setProduto_id(rs.getInt("produto_id"));

            lstpedido.add(l);
        }
        st.close();
        rs.close();
        if(lstpedido.size() > 0){
            return 1; //caso já tenha algum produto relacionado a categoria que quero exclir
        }else{
            return 0; //caso já tenha algum produto relacionado a categoria que quero exclir
        }
     }
     
     public boolean excluir(int id) throws SQLException, ClassNotFoundException {
        Conexao conn = new Conexao();
        String sql = "DELETE FROM produto WHERE id=?";

        PreparedStatement st = conn.prepareStatement(sql);
        st.setInt(1, id);
        
        int ret = st.executeUpdate();
        st.close();
        return ret > 0; //delete funcionou
    }
     
     public boolean atualizar(Produto l) throws ClassNotFoundException, SQLException {
        Conexao conn = new Conexao();
        String sql = "UPDATE produto SET categoria_id=?, descricao =?, preco =? WHERE id=?";

        PreparedStatement st = conn.prepareStatement(sql);
        st.setInt(1, l.getCategoria_idCategoria());
        st.setString(2,l.getDescricao());
        st.setDouble(3, l.getPreco());
        st.setInt(4, l.getIdProduto());
        

        int ret = st.executeUpdate();
        st.close();
        return ret > 0; //update funcionou
    }
}
