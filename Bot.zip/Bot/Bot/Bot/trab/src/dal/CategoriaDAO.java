/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dal;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import model.Categoria;
import model.Produto;

/**
 *
 * @author gabri
 */
public class CategoriaDAO {
    //excluir categoria passando qual o id da categoria a excluir
    public boolean excluir(int id) throws SQLException, ClassNotFoundException {
        Conexao conn = new Conexao();
        String sql = "DELETE FROM categoria WHERE id=?";

        PreparedStatement st = conn.prepareStatement(sql);
        st.setInt(1, id);
        
        int ret = st.executeUpdate();
        st.close();
        return ret > 0; //delete funcionou
    }
    
    //atualizar uma categoria passando qual a categoria
    public boolean atualizar(Categoria l) throws ClassNotFoundException, SQLException {
        Conexao conn = new Conexao();
        String sql = "UPDATE categoria SET descricao=? WHERE id=?";

        PreparedStatement st = conn.prepareStatement(sql);
        st.setString(1, l.getDescricao());
        st.setInt(2,l.getIdCategoria());
        

        int ret = st.executeUpdate();
        st.close();
        return ret > 0; //update funcionou
    }
    //insere nova categoria passando os valores a serem adicionados
    public boolean inserir(Categoria a) throws SQLException, ClassNotFoundException {
        //conexao com o banci de dados
        Conexao conn = new Conexao();
        //script
        PreparedStatement st = conn.prepareStatement("insert into categoria(descricao) values ( ? ) ");
  
        st.setString(1, a.getDescricao());
        
        int ret = st.executeUpdate();
        if (ret > 0) {
            return true;//significa que inseriu corretamente
        } else {
            return false;//significa que não inseriu
        }
    }
    //consulta de tosas a categorias
    public ArrayList<Categoria> consultar() throws SQLException, ClassNotFoundException {
        ArrayList<Categoria> lstRet = new ArrayList<>();
        Conexao conn = new Conexao();
        //faz a consulta no BD
        String sql = "SELECT * FROM categoria";

        PreparedStatement st = conn.prepareStatement(sql);
        ResultSet rs = st.executeQuery();
        while (rs.next()) {
            Categoria l = new Categoria();
            l.setIdCategoria(rs.getInt("id"));
            l.setDescricao(rs.getString("descricao"));

            lstRet.add(l);
        }
        st.close();
        rs.close();
        return lstRet; //retorna uma lista com as categoeias existentes no banco de dados
    }
    //verificaão para quando tentar excluir uma categoria verificar se já não existe produto com aquele id de categoria
    public int TemCat(int idcat) throws ClassNotFoundException, SQLException{
         ArrayList<Produto> lstprod = new ArrayList<>(); //carrega os produto
        Conexao conn = new Conexao();
        //consulta pra ve se nehum produto ta ligado a categoria que quer excluir
        String sql = "SELECT * FROM produto where categoria_id = ?";

        PreparedStatement st = conn.prepareStatement(sql);
        st.setInt(1, idcat);
        ResultSet rs = st.executeQuery();
        while (rs.next()) {
            Produto l = new Produto();

            l.setIdProduto(rs.getInt("id"));
            l.setDescricao(rs.getString("descricao"));

            lstprod.add(l);
        }
        st.close();
        rs.close();
        if(lstprod.size() > 0){
            return 1; //caso já tenha algum produto relacionado a categoria que quero exclir
        }else{
            return 0; //caso já tenha algum produto relacionado a categoria que quero exclir
        }
    }
}
