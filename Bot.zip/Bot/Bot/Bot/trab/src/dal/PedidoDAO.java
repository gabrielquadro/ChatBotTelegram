package dal;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import model.Categoria;

public class PedidoDAO {
    public boolean entregar(int id) throws ClassNotFoundException, SQLException {
        System.out.println("id " + id);
        Conexao conn = new Conexao();
        String sql = "UPDATE pedido SET entregue=1 WHERE id=?";

        PreparedStatement st = conn.prepareStatement(sql);
        st.setInt(1, id);
        

        int ret = st.executeUpdate();
        st.close();
        return ret > 0; //update funcionou
    }
}
