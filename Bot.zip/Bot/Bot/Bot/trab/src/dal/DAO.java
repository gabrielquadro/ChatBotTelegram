package dal;

import model.*;
import java.sql.*;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class DAO<T> {
    public Connection con;
    
    public DAO() throws ClassNotFoundException, SQLException {
        Conexao c = new Conexao();
        con = c.getConexao();
    }
    
    //inserir
    public void inserir(Object obj) throws SQLException{
        Statement st = con.createStatement();
        
        String queryInsert = "insert into";
        
        /*Caso a classe seja uma categoria*/
        if(obj instanceof Categoria){
            Categoria cat = (Categoria) obj;
            queryInsert += " categoria(descricao) values ('"+cat.getDescricao()+"')";
            st.execute(queryInsert);
            JOptionPane.showMessageDialog(null, "Registro cadastrado!");
        }else if(obj instanceof Produto){
            Produto pro = (Produto) obj;
            double novoPreco = pro.getCategoria_idCategoria();
            queryInsert += " produto (descricao, preco, categoria_id) VALUES ('"+pro.getDescricao()+"',"+pro.getPreco()+", "+pro.getCategoria_idCategoria()+")";
            st.execute(queryInsert);
            JOptionPane.showMessageDialog(null, "Registro cadastrado!");
        }else if(obj instanceof Cliente){
            Cliente novoCli = (Cliente) obj;
            String query = "INSERT INTO cliente (`id`, `Nome`) VALUES ("+novoCli.getIdCliente()+", '"+novoCli.getNomeCliente()+"')";
            st.execute(query);
        }else if(obj instanceof Pedido){
            Pedido novoPed = (Pedido) obj;
            String query = "INSERT INTO pedido (data, finalizado, entregue, cliente_id) VALUES ('"+novoPed.getData()+"', "+novoPed.getFinalizado()+", "+novoPed.getEntregue()+", "+novoPed.getCliente_idCliente()+")";
            st.execute(query);
        }else if(obj instanceof PedidoItem){
            PedidoItem novoPedI = (PedidoItem) obj;
            String query = "INSERT INTO pedido_item (produto_id, pedido_id, quantidade, preco, observacao) VALUES ("+novoPedI.getProduto_id()+", "+novoPedI.getPedido_id()+", "+novoPedI.getQuantidade()+", "+novoPedI.getPreco()+", '"+novoPedI.getObservacao()+"')";
            st.execute(query);
        }else{
            JOptionPane.showMessageDialog(null, "Classe Inválida ou sem tratamento");
        }
    }
    
    
    //carrega todos os objetos selecionados de <T>
    public ArrayList<T> todosRegistros(Class classe, int pedido, int categoria) throws SQLException{
        Statement st = con.createStatement();
        ResultSet rs;
        
        String queryConsulta = "SELECT * FROM";
        
        ArrayList<T> lstRegistros = new ArrayList();
        
        if(classe == Categoria.class){
            lstRegistros = new ArrayList();
            queryConsulta += " categoria";
            rs = st.executeQuery(queryConsulta);
            
            while (rs.next()){
                Categoria newCat = new Categoria();
                newCat.setIdCategoria(rs.getInt("id"));
                newCat.setDescricao(rs.getString("descricao"));
                lstRegistros.add((T) newCat);
            }            
            
            return lstRegistros;
        }else if(classe == Produto.class){
            if(categoria > 0){
                queryConsulta += " produto WHERE categoria_id ="+categoria;
                rs = st.executeQuery(queryConsulta);

                while (rs.next()){
                    Produto Produto = new Produto();
                    Produto.setIdProduto(rs.getInt("id"));
                    Produto.setDescricao(rs.getString("descricao"));
                    Produto.setPreco(rs.getFloat("preco"));
                    Produto.setCategoria_idCategoria(rs.getInt("categoria_id"));
                    lstRegistros.add((T)Produto);
                }        
            }else{
                queryConsulta += " produto";
                rs = st.executeQuery(queryConsulta);

                while (rs.next()){
                    Produto newProduto = new Produto();
                    newProduto.setIdProduto(rs.getInt("id"));
                    newProduto.setDescricao(rs.getString("descricao"));
                    newProduto.setPreco(rs.getFloat("preco"));
                    newProduto.setCategoria_idCategoria(rs.getInt("categoria_id"));
                    lstRegistros.add((T)newProduto);
                }        
            }    
            
            return lstRegistros;
        }else if(classe == Pedido.class){
            queryConsulta += " pedido WHERE entregue = 0 and finalizado = 1";
            rs = st.executeQuery(queryConsulta);
                    
            while (rs.next()){
                Pedido ped = new Pedido();
                ped.setIdPedido(rs.getInt("id"));
                ped.setData(rs.getTimestamp("data"));
                ped.setFinalizado(rs.getInt("finalizado"));
                ped.setEntregue(rs.getInt("entregue"));
                ped.setCliente_idCliente(rs.getInt("cliente_id"));
                lstRegistros.add((T)ped);
            }
            
            return lstRegistros;
        }else if(classe == PedidoItem.class){
            queryConsulta += " pedido_item WHERE pedido_id = "+pedido;
            rs = st.executeQuery(queryConsulta);
            
            while(rs.next()){
                PedidoItem pedItem = new PedidoItem();
                pedItem.setProduto_id(rs.getInt("produto_id"));
                pedItem.setPedido_id(rs.getInt("pedido_id"));
                pedItem.setQuantidade(rs.getInt("quantidade"));
                pedItem.setPreco(rs.getDouble("preco"));
                pedItem.setObservacao(rs.getString("observacao"));
                lstRegistros.add((T)pedItem);
            }
            
            return lstRegistros;
        }else if (classe == Cliente.class) {
            lstRegistros = new ArrayList();
            queryConsulta += " cliente";
            rs = st.executeQuery(queryConsulta);

            while (rs.next()) {
                Cliente newCli = new Cliente();
                newCli.setIdCliente(rs.getInt("id"));
                newCli.setNomeCliente(rs.getString("nome"));
                lstRegistros.add((T) newCli);
            }

            return lstRegistros;
        } else{
            JOptionPane.showMessageDialog(null, "Classe Inválida ou sem tratamento");
            return null;
        }        
    }
    
    /**
     * Metodo para pegar ultimo id cadastrado e adicionar mais 1, para assim ser
     * possivel mostrar o novo id do novo cadastro, caso o retorno da consulta 
     * seje igual a null seria retornado o valor 1 para primeiro cadastro.
     */
    public String ultimoRegistro(Class classe) throws SQLException, ClassNotFoundException{
        int ultimoRegistro = 0;
        
        Statement st = con.createStatement();
        ResultSet rs = null;
        
        String queryConstula = "SELECT MAX(";
        
        if(classe == Categoria.class){
            queryConstula += "id) as ultimoRegistro FROM categoria";
            rs = st.executeQuery(queryConstula);                        
            
            if(rs != null && rs.next()){
                ultimoRegistro = rs.getInt("ultimoRegistro");
                ultimoRegistro++;
            }else{
                ultimoRegistro = 1;
            }
        }else if(classe == Produto.class){
            queryConstula += "id) as ultimoRegistro FROM produto";
            rs = st.executeQuery(queryConstula);
            
            if(rs != null && rs.next()){
                ultimoRegistro = rs.getInt("ultimoRegistro");
                ultimoRegistro++;
            }else{
                ultimoRegistro = 1;
            }
        }else{
            JOptionPane.showMessageDialog(null, "Classe Inválida ou sem tratamento");
        }        
        
        return String.valueOf(ultimoRegistro);
    }
    
    //atualzir informações
    public void alterarRegistro(Object obj) throws SQLException{
        Statement st = con.createStatement();
        
        String query = "";
        
        if(obj instanceof Categoria){
            Categoria alterCat = (Categoria) obj;
            query = "update categoria set descricao = '"+alterCat.getDescricao()+"'"
                    + " where id = "+alterCat.getIdCategoria()+"";
            
            st.executeUpdate(query);
        }else if(obj instanceof Produto){
            Produto alterProduto = (Produto) obj;
            query = "update produto set descricao = '"+alterProduto.getDescricao()+"', preco = '"+alterProduto.getPreco()+"', "
                    + "categoria_id"
                    + " = '"+alterProduto.getCategoria_idCategoria()+"' where id ="+alterProduto.getIdProduto();
            st.executeUpdate(query);
        }else{
            JOptionPane.showMessageDialog(null, "Classe nao possue tratamento");
        }
        
        JOptionPane.showMessageDialog(null, "Classe Inválida ou sem tratamento");
    }
    
    //excluir registro
    public void excluirRegistro(int opcao, Object obj) throws SQLException{
        Statement st = con.createStatement();
        
        if(opcao == 1){
            
            Categoria excluirCat = (Categoria) obj;
            String query = "DELETE FROM categoria WHERE id = "+excluirCat.getIdCategoria();
            st.executeUpdate(query);
            
        }else if(opcao == 2){
            
            String query = "DELETE FROM produto WHERE id = "+obj;
            st.executeUpdate(query);
                       
        }else{
            JOptionPane.showMessageDialog(null, "Sem tratamento para essa classe!");
        }
        
        JOptionPane.showMessageDialog(null, "Registro excluido com sucesso!");
    }
    
    
    public Produto consultaProduto(int codProd) throws SQLException{
        Statement st = con.createStatement();
        
        String queryConsulta = "SELECT * FROM produto WHERE id = "+codProd;
        ResultSet rs = st.executeQuery(queryConsulta);

        if(rs != null && rs.next()){
            Produto prod = new Produto();
            prod.setIdProduto(rs.getInt("id"));
            prod.setDescricao(rs.getString("descricao"));
            prod.setPreco(rs.getFloat("preco"));
            prod.setCategoria_idCategoria(rs.getInt("categoria_id"));
            return prod;
        }else{
            return null;
        }
    }
    
    
    public Cliente consultaCliente(int idTelegran) throws SQLException{
        Statement st = con.createStatement();
        
        String queryConsulta = "SELECT * FROM cliente WHERE id = "+idTelegran;
        ResultSet rs = st.executeQuery(queryConsulta);

        if(rs != null && rs.next()){
            Cliente cli = new Cliente();
            cli.setIdCliente(rs.getInt("id"));
            cli.setNomeCliente(rs.getString("nome"));
            return cli;
        }else{
            //cliente novo
            //JOptionPane.showMessageDialog(null, "Consulta do cliente veio vazia");
            return null;
        }
    }
    
    /**
    Com opção 1 irá realizara consulta no pedidoItem para retornar
     * o preço total de um pedido especifico.
     * cod1: Serve para validar nos IF's qual consulta seria realizada
     * cod1 = 1(Select que retornar o preço total de um pedido)
     * cod1 = 2(Ira alterar o pedido para entregue = 1)
     * cod2 - Manda a PK para poder fazer a operação necessária
     */
    public float diversos(int cod1, int cod2) throws SQLException{
        Statement st = con.createStatement();
        
        if(cod1 == 1){
            String query = "SELECT SUM((preco*quantidade)) AS precoTotal FROM pedido_item WHERE pedido_id ="+cod2;
            ResultSet rs = st.executeQuery(query);
            
            if(rs != null && rs.next()){
                return rs.getFloat("precoTotal"); 
            }else{
                return 0;
            }
        }else if(cod1 == 2){
            String query = "UPDATE pedido SET entregue = 1 WHERE id = "+cod2;
            st.executeUpdate(query);
            return 0;
        }else{
            JOptionPane.showMessageDialog(null, "Classe Inválida ou sem tratamento");
            return 0;
        }
    }
}