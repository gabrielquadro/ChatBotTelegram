/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package View;

import dal.CategoriaDAO;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import model.Categoria;

/**
 *
 * @author gabri
 */
public class TelaManCat extends javax.swing.JFrame {

    CategoriaDAO cat = new CategoriaDAO();
    private ArrayList<Categoria> lst;
    //Categoria a;
    int linha;

    public TelaManCat() throws ClassNotFoundException, SQLException {
        initComponents();
        //seta pra não poder maximizar a tela
        //this.setResizable(false);
        montarTabela();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        tabela_cat = new javax.swing.JTable();
        atualizarTabela = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        btnAlterarCat = new javax.swing.JButton();
        txtDescricao = new javax.swing.JTextField();
        btnInserirCat = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        btnNovaCat = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Manutenção de categoria");

        tabela_cat.setBackground(new java.awt.Color(204, 255, 204));
        tabela_cat.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(153, 0, 153), 1, true));
        tabela_cat.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Descrição"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(tabela_cat);

        atualizarTabela.setIcon(new javax.swing.ImageIcon(getClass().getResource("/View/Actions-edit-redo-icon.png"))); // NOI18N
        atualizarTabela.setText("Atualizar Tabela");
        atualizarTabela.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                atualizarTabelaActionPerformed(evt);
            }
        });

        jButton2.setBackground(new java.awt.Color(255, 102, 102));
        jButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/View/Close-icon.png"))); // NOI18N
        jButton2.setText("Excluir");
        jButton2.setBorder(new javax.swing.border.MatteBorder(null));
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        btnAlterarCat.setIcon(new javax.swing.ImageIcon(getClass().getResource("/View/Actions-edit-redo-icon.png"))); // NOI18N
        btnAlterarCat.setText("Atualizar Categoria");
        btnAlterarCat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAlterarCatActionPerformed(evt);
            }
        });

        txtDescricao.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtDescricaoActionPerformed(evt);
            }
        });

        btnInserirCat.setBackground(new java.awt.Color(153, 255, 153));
        btnInserirCat.setIcon(new javax.swing.ImageIcon(getClass().getResource("/View/Accept-icon.png"))); // NOI18N
        btnInserirCat.setMnemonic('s');
        btnInserirCat.setText("Inserir");
        btnInserirCat.setToolTipText("Alt + s inserir");
        btnInserirCat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnInserirCatActionPerformed(evt);
            }
        });

        jLabel3.setText("Descrição");

        btnNovaCat.setIcon(new javax.swing.ImageIcon(getClass().getResource("/View/Accept-icon.png"))); // NOI18N
        btnNovaCat.setText("Atualizar categoria");
        btnNovaCat.setEnabled(false);
        btnNovaCat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNovaCatActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(btnAlterarCat, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 227, Short.MAX_VALUE)
                    .addComponent(jButton2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(atualizarTabela, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(35, 35, 35))
            .addGroup(layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(btnInserirCat, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(37, 37, 37)
                        .addComponent(btnNovaCat, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 1, Short.MAX_VALUE)
                        .addGap(18, 18, 18)
                        .addComponent(txtDescricao)
                        .addGap(38, 38, 38)))
                .addGap(139, 139, 139))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(txtDescricao, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(29, 29, 29)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(btnInserirCat, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnNovaCat, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(34, 34, 34)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(atualizarTabela)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnAlterarCat))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 156, Short.MAX_VALUE))
                .addContainerGap())
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents
    private void montarTabela() throws SQLException, ClassNotFoundException {
        //código que carrega a lista de livros para a JTable
        DefaultTableModel m = (DefaultTableModel) tabela_cat.getModel();
        m.setRowCount(0);//limpar minha tabela

        lst = cat.consultar();

        for (int i = 0; i < lst.size(); i++) {
            Object linha[] = new Object[5];
            Categoria temp = lst.get(i);
            //linha[0] = temp.getId();
            linha[0] = temp.getDescricao();

            m.addRow(linha);//adicionar a linha
        }
    }
    private void btnAlterarCatActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAlterarCatActionPerformed
        btnNovaCat.setEnabled(true);
        btnInserirCat.setEnabled(false);

        linha = tabela_cat.getSelectedRow();//linha selecionada
        if (linha != -1) {
            try {
                CategoriaDAO dao = new CategoriaDAO();
                lst = cat.consultar();
                txtDescricao.setText(lst.get(linha).getDescricao());
                linha = lst.get(linha).getIdCategoria();

            } catch (ClassNotFoundException ex) {
                JOptionPane.showMessageDialog(this, ex.getMessage(), "ERRO", JOptionPane.ERROR_MESSAGE);
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(this, ex.getMessage(), "ERRO", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(this, "Selecione a categoria a ser atualizada por favor");
        }

    }//GEN-LAST:event_btnAlterarCatActionPerformed

    private void btnInserirCatActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnInserirCatActionPerformed

        try {
            insereNovo();
            montarTabela();
            JOptionPane.showMessageDialog(this, "Inserido com sucesso");
        } catch (SQLException ex) {
            Logger.getLogger(TelaManCat.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(TelaManCat.class.getName()).log(Level.SEVERE, null, ex);
        }


    }//GEN-LAST:event_btnInserirCatActionPerformed

    private void atualizarTabelaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_atualizarTabelaActionPerformed
        try {
            montarTabela();
        } catch (SQLException ex) {
            Logger.getLogger(TelaManCat.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(TelaManCat.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_atualizarTabelaActionPerformed

    private void btnNovaCatActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNovaCatActionPerformed
        CategoriaDAO dao = new CategoriaDAO();
        try {
            //agora que tenho os dados na categoria        
            Categoria a = new Categoria();
            a.setIdCategoria(linha);
            a.setDescricao(txtDescricao.getText());
            dao.atualizar(a);//mando o DAO fazer o update
            btnNovaCat.setEnabled(false);
            btnInserirCat.setEnabled(true);
            JOptionPane.showMessageDialog(this, "Atualizado com sucesso");
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(TelaManCat.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(TelaManCat.class.getName()).log(Level.SEVERE, null, ex);
        }
        try {
            montarTabela();
        } catch (SQLException ex) {
            Logger.getLogger(TelaManCat.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(TelaManCat.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_btnNovaCatActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        linha = tabela_cat.getSelectedRow();//linha selecionada
        if (linha != -1) {
            try {
                CategoriaDAO dao = new CategoriaDAO();
                lst = cat.consultar();
                linha = lst.get(linha).getIdCategoria();
                //verifica se já não tem produto vinculado a categoria
                if (dao.TemCat(linha) != 1) {
                    int resposta = JOptionPane.showConfirmDialog(null, "Deseja realmente excluir?", "Excluir", JOptionPane.YES_NO_OPTION);

                    if (resposta == JOptionPane.YES_OPTION) {
                        //Usuário clicou em Sim. Executar o código correspondente.
                        dao.excluir(linha);//mando o DAO fazer o update
                        montarTabela();
                    } else if (resposta == JOptionPane.NO_OPTION) {
                      //Usuário clicou em não. Executar o código correspondente.
                        JOptionPane.showMessageDialog(this, "Exclusão cancelada");
                    }
                    

                } else {
                    JOptionPane.showMessageDialog(this, "Já existe produto vinculado a categoria!");
                }
            } catch (ClassNotFoundException ex) {
                JOptionPane.showMessageDialog(this, ex.getMessage(), "ERRO", JOptionPane.ERROR_MESSAGE);
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(this, ex.getMessage(), "ERRO", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(this, "Selecione a categoria a ser atualizada por favor");
        }
    }//GEN-LAST:event_jButton2ActionPerformed

    private void txtDescricaoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtDescricaoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtDescricaoActionPerformed

    public void insereNovo() throws SQLException, ClassNotFoundException {

        String descricao = txtDescricao.getText();

        Categoria c = new Categoria(descricao);

        cat.inserir(c);

    }

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(TelaManCat.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(TelaManCat.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(TelaManCat.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(TelaManCat.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    new TelaManCat().setVisible(true);
                } catch (ClassNotFoundException ex) {
                    Logger.getLogger(TelaManCat.class.getName()).log(Level.SEVERE, null, ex);
                } catch (SQLException ex) {
                    Logger.getLogger(TelaManCat.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton atualizarTabela;
    private javax.swing.JButton btnAlterarCat;
    private javax.swing.JButton btnInserirCat;
    private javax.swing.JButton btnNovaCat;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tabela_cat;
    private javax.swing.JTextField txtDescricao;
    // End of variables declaration//GEN-END:variables
}
