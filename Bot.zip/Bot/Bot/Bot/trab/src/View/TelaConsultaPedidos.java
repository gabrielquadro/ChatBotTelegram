package View;

import dal.CategoriaDAO;
import dal.PedidoDAO;
import dal.PedidoItemDAO;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import model.Categoria;
import model.Pedido;
import model.PedidoItem;
import model.Produto;
import model.Cliente;

public class TelaConsultaPedidos extends javax.swing.JFrame {

    PedidoItemDAO cat = new PedidoItemDAO();
    private ArrayList<PedidoItem> lst;
    private ArrayList<Pedido> lstPedido;
    int linha;

    public TelaConsultaPedidos() throws SQLException, ClassNotFoundException {
        super("Consulta de  pedidos");
        initComponents();
        //seta pra não poder maximizar a tela
        //this.setResizable(false);
        montarTabela();
    }

    private void montarTabela() throws SQLException, ClassNotFoundException {
//        //código que carrega a lista de livros para a JTable
//        DefaultTableModel m = (DefaultTableModel) tabela_pedido_item.getModel();
//        m.setRowCount(0);//limpar minha tabela
//
//        lst = cat.consultar();
//        lstPedido = cat.consultarPedido(lst.get(0).getPedido_id());
//        if (lstPedido.get(0).getEntregue() == 0) {
//            for (int i = 0; i < lst.size(); i++) {
//                lstPedido = cat.consultarPedido(lst.get(linha).getPedido_id());
//                Object linha[] = new Object[5];
//                Pedido p = lstPedido.get(i);
//                PedidoItem temp = lst.get(i);
//                //linha[0] = temp.getId();
//                linha[0] = temp.getPedido_id();
//                linha[1] = p.getCliente_idCliente();
//                linha[2] = p.getData();
//                linha[3] = temp.getPreco();
//                m.addRow(linha);
//            }
//        }
         limpaTabelaListaItens();
        DefaultTableModel jTable = (DefaultTableModel) tabela_pedido_item.getModel();
        float sumTotalPedido = 0;
        ArrayList<Pedido> lstPedidos = new ArrayList();
        
        for (int i = 0; i < jTable.getRowCount(); i++) {
            jTable.removeRow(0);
        }
        
        /*Limpando a tabela dos pedidos*/
        for (int i = 0; i < jTable.getRowCount(); i++) {
            jTable.removeRow(i);
        }
        
       
            dal.DAO<Pedido> dao = new dal.DAO();
            
            lstPedidos = dao.todosRegistros(Pedido.class, 0, 0);            
            
            if(!lstPedidos.isEmpty()){
                for (int i = 0; i < lstPedidos.size(); i++) {
                    sumTotalPedido = dao.diversos(1, lstPedidos.get(i).getIdPedido());
                    Cliente cli = dao.consultaCliente(lstPedidos.get(i).getCliente_idCliente());
                    SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy HH:mm");
                    String DataConvertida  = dateFormat.format(lstPedidos.get(i).getData());
                    Object[] add = {lstPedidos.get(i).getIdPedido(), cli.getNomeCliente(), DataConvertida, sumTotalPedido};
                    jTable.addRow(add);
                }
            }            
            
       
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel4 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        finalizarEntrega = new javax.swing.JButton();
        jScrollPane3 = new javax.swing.JScrollPane();
        tabela_pedido_item = new javax.swing.JTable();
        jLabel2 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabelaPedido = new javax.swing.JTable();

        jLabel4.setText("jLabel4");

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Consulta de Pedidos");
        setMinimumSize(new java.awt.Dimension(520, 320));

        jLabel1.setBackground(new java.awt.Color(255, 102, 102));
        jLabel1.setText("Pedidos em Espera");

        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/View/Accept-icon.png"))); // NOI18N
        jButton1.setText("Atualizar Tela");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        finalizarEntrega.setIcon(new javax.swing.ImageIcon(getClass().getResource("/View/Actions-edit-redo-icon.png"))); // NOI18N
        finalizarEntrega.setText("Finalizar Entrega");
        finalizarEntrega.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                finalizarEntregaActionPerformed(evt);
            }
        });

        tabela_pedido_item.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Nº Pedido", "Cliente", "Data/Hora", "Valor total"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.Float.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tabela_pedido_item.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tabela_pedido_itemMouseClicked(evt);
            }
        });
        jScrollPane3.setViewportView(tabela_pedido_item);

        jLabel2.setText("Item do pedido selecionado");

        tabelaPedido.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Cod.Produto", "Descrição", "Observação", "Qtde", "Valor"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.Integer.class, java.lang.Float.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(tabelaPedido);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(309, 309, 309))
            .addGroup(layout.createSequentialGroup()
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                .addGap(57, 57, 57)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jButton1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(finalizarEntrega, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(30, 30, 30)
                        .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(242, 242, 242))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addComponent(jScrollPane1)))
                .addGap(47, 47, 47))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(10, 10, 10)
                .addComponent(jLabel1)
                .addGap(6, 6, 6)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(jButton1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(finalizarEntrega)
                        .addGap(0, 13, Short.MAX_VALUE)))
                .addGap(20, 20, 20)
                .addComponent(jLabel2)
                .addGap(6, 6, 6)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 120, Short.MAX_VALUE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        try {
            montarTabela();
        } catch (SQLException ex) {
            Logger.getLogger(TelaConsultaPedidos.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(TelaConsultaPedidos.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jButton1ActionPerformed

    private void finalizarEntregaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_finalizarEntregaActionPerformed
        linha = tabela_pedido_item.getSelectedRow();//linha selecionada
        if (linha != -1) {
             dal.DAO dao = null;
            try {
                dao = new dal.DAO();
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(TelaConsultaPedidos.class.getName()).log(Level.SEVERE, null, ex);
            } catch (SQLException ex) {
                Logger.getLogger(TelaConsultaPedidos.class.getName()).log(Level.SEVERE, null, ex);
            }
            try {
                dao.diversos(2, (int) tabela_pedido_item.getValueAt(tabela_pedido_item.getSelectedRow(), 0));
            } catch (SQLException ex) {
                Logger.getLogger(TelaConsultaPedidos.class.getName()).log(Level.SEVERE, null, ex);
            }
            try {
                montarTabela();
            } catch (SQLException ex) {
                Logger.getLogger(TelaConsultaPedidos.class.getName()).log(Level.SEVERE, null, ex);
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(TelaConsultaPedidos.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }//GEN-LAST:event_finalizarEntregaActionPerformed

    private void tabela_pedido_itemMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tabela_pedido_itemMouseClicked
        int linhaSelecionada = tabela_pedido_item.getSelectedRow();
        int codPedido = Integer.parseInt(tabela_pedido_item.getValueAt(linhaSelecionada, 0).toString());

        limpaTabelaListaItens();
        try {
            atualizaListaItens(codPedido);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(TelaConsultaPedidos.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(TelaConsultaPedidos.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_tabela_pedido_itemMouseClicked
    public void limpaTabelaListaItens(){
        DefaultTableModel jTable = (DefaultTableModel) tabelaPedido.getModel();
        
        /*Limpando tabela dos itens*/
        if(jTable.getRowCount() > 0){    
            for (int j = 0 ; j <= jTable.getRowCount() ; j ++) {                
                jTable.removeRow(0);
            }
        }
        
        /*Limpando a tabela dos pedidos*/
        for (int i = 0; i < jTable.getRowCount(); i++) {
            jTable.removeRow(i);
        }
    }
    public void atualizaListaItens(int numeroPedido) throws ClassNotFoundException, SQLException{
        DefaultTableModel jTable = (DefaultTableModel) tabelaPedido.getModel();
        
       
            
            dal.DAO dao = new dal.DAO();

            ArrayList<PedidoItem> lstPedidoItem = dao.todosRegistros(PedidoItem.class, numeroPedido, 0);
            
            if(!lstPedidoItem.isEmpty()){
                for (int i = 0; i < lstPedidoItem.size(); i++) {
                    Produto pro = dao.consultaProduto(lstPedidoItem.get(i).getProduto_id());
                    Object[] add = {lstPedidoItem.get(i).getProduto_id(), pro.getDescricao(),lstPedidoItem.get(i).getObservacao(), 
                        lstPedidoItem.get(i).getQuantidade(), lstPedidoItem.get(i).getPreco(), "R$"+lstPedidoItem.get(i).getQuantidade()*lstPedidoItem.get(i).getPreco()};
                    jTable.addRow(add);
                }
            }
            
       
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(TelaConsultaPedidos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(TelaConsultaPedidos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(TelaConsultaPedidos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(TelaConsultaPedidos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    new TelaConsultaPedidos().setVisible(true);
                } catch (SQLException ex) {
                    Logger.getLogger(TelaConsultaPedidos.class.getName()).log(Level.SEVERE, null, ex);
                } catch (ClassNotFoundException ex) {
                    Logger.getLogger(TelaConsultaPedidos.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton finalizarEntrega;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTable tabelaPedido;
    private javax.swing.JTable tabela_pedido_item;
    // End of variables declaration//GEN-END:variables
}
