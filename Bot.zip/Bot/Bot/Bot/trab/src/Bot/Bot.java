package Bot;

import java.io.*;
import java.net.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Bot {

    private String tokenBot;//armazena o token do bot

    public Bot(String token) {
        this.tokenBot = token;// Inicialização da variavel Token que vai receber por parametro o Token do Bot
    }
    
    /*
     Metodo que recebe a String gerada pelo bot.
     Faz o recorte, após responde
     */
    public RecorteInformacoes recebeMensagem() {
        //link de recepção das mensagens do Telegran
        String url = String.format("https://api.telegram.org/bot%s/getUpdates", tokenBot);
        //classe que irá fazer o recorte de informções de usuário
        RecorteInformacoes recorte_info;

        try {
            //Cria a conexao telegram
            URL telegram = new URL(url);
            URLConnection con = telegram.openConnection();
            BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
            
            //Leitura de uma String de mensagem por vez
            String linha = in.readLine() + in.readLine();
            
            //inicia se tudo ok
            if (!linha.equals("{\"ok\":true,\"result\":[]}null")) {
                //passa a mensagem recebida paar recortes
                recorte_info = new RecorteInformacoes(linha);
                
                //Coneção com o site do Telegran novamente para apagar a mensagem que ja foi executada
                url = String.format("https://api.telegram.org/bot%s/getUpdates?offset=%s", tokenBot, recorte_info.getUpdate_id() + 1);
                telegram = new URL(url);
                con = telegram.openConnection();
                in = new BufferedReader(new InputStreamReader(con.getInputStream()));
                
                //Retorna o tratamento de String
                return recorte_info;
            }

        } catch (MalformedURLException ex) {
            Logger.getLogger(Bot.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(Bot.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        //Caso não tenha recebido novas mensagens retorna null
        return null;
    }

    /*
    Realiza o envio de mensagens ao usuário 
    */
    public void enviarMensagem(String idDest, String msg) {
        //Criação do link de envio da mensagem
        String s = String.format("https://api.telegram.org/bot%s/sendMessage?chat_id=%s&text=%s", tokenBot, idDest, msg);

        try {
            //Conecção com o link do Telegran
            URL telegram = new URL(s);
            URLConnection tc = telegram.openConnection();
            BufferedReader in = new BufferedReader(new InputStreamReader(tc.getInputStream()));

        } catch (MalformedURLException ex) {
            Logger.getLogger(Bot.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(Bot.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

}
