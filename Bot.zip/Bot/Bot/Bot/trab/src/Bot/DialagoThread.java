package Bot;

import model.Categoria;
import model.Produto;
import model.Pedido;
import model.PedidoItem;
import java.util.Date;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

public class DialagoThread extends Thread {

    private int id_cliente;
    private String mensagem_recebida;
    private int controlador;
    private PedidoItem pedido_item;
    private Pedido pedido;
    private ArrayList<Categoria> lstCat;
    private ArrayList<Produto> lstProd;
    private ArrayList<Pedido> lstPed;
    private int ehCategoria;
    private int ehProduto;
    private int quantidade;
    private boolean boo;
    private boolean addInfoSouN;

    public DialagoThread(RecorteInformacoes t) throws ClassNotFoundException, SQLException {
        this.id_cliente = t.getUser_id();
        this.mensagem_recebida = t.getMensagem();
        this.controlador = 0;
        this.pedido_item = new PedidoItem();
        this.pedido = new Pedido();
        this.ehCategoria = 0;
        this.ehProduto = 0;
        this.quantidade = 0;
        this.boo = false;
        this.addInfoSouN = true;
    }

    public DialagoThread(int cliId, String cliNome) {
        this.id_cliente = cliId;
        this.controlador = 0;
        this.pedido_item = new PedidoItem();
        this.pedido = new Pedido();
        this.ehCategoria = 0;
        this.ehProduto = 0;
        this.quantidade = 0;
        this.boo = false;
        this.addInfoSouN = true;
    }
    //vai responder as mensagens do bot , recebe a mensagem e quem é o bot
    public void responder(RecorteInformacoes t, Bot b) throws SQLException, ParseException {
        try {
            this.mensagem_recebida = t.getMensagem();

            switch (controlador) {
                //primeira mensagem cotrolador = 0 pra fazer a recepção ao usuário
                case 0:
                    //da o olá e carrega as categorias existentes  e mostra ao usuário
                    dal.DAO dao_categoria = new dal.DAO();
                    //carrega as categoria
                    lstCat = dao_categoria.todosRegistros(Categoria.class, 0, 0);

                    //da boas vindas ao usuário
                    b.enviarMensagem(Integer.toString(id_cliente), "Ola,%20seja%20bem%20vindo%20ao%20monstro%20lanches%20,%20digite%20o%20codigo%20da%20categoria%20que%20deseja%20a%20seguir:");

                    //envia as categorias pro usuário
                    for (int i = 0; i < lstCat.size(); i++) {
                        b.enviarMensagem(Integer.toString(id_cliente), (Integer.toString(lstCat.get(i).getIdCategoria()) + "%20" + lstCat.get(i).getDescricao()));
                    }
                    //Incrementa no contador para saber em qual parte do pedido está
                    controlador++;
                    break;

                case 1:
                    //verifica a categoria que o usuario colocou se é verdadeira ou não
                    //tratamento para caso o usuario digite um ou Um em vez de 1
                    int num = testaValorPassado(mensagem_recebida);
                    String num1 = Integer.toString(num);
                    for (int i = 0; i < lstCat.size(); i++) {
                        //if pra verificar se 1(valor passado) existe nos id das categorias
                        if (mensagem_recebida.contains(lstCat.get(i).getDescricao()) || mensagem_recebida.contains(Integer.toString(lstCat.get(i).getIdCategoria()))) {
                            ehCategoria = i + 1;
                        //if pra verificar se um ou UM(valor passado que agora é 1) existe nos id das categorias
                        } else if (num1.contains(lstCat.get(i).getDescricao()) || num1.contains(Integer.toString(lstCat.get(i).getIdCategoria()))) {
                            ehCategoria = i + 1;
                        }

                    }

                    if (ehCategoria != 0) {//Se for uma categoria existente no banco

                        //carrega e diz a lista de produtos daquela categoria
                        dal.DAO daoP = new dal.DAO();
                        //carrega a lista de produtos da categoria
                        lstProd = daoP.todosRegistros(Produto.class, 0, ehCategoria);
                        //envia pro usuário os produtos da categoria
                        b.enviarMensagem(Integer.toString(id_cliente), "Escolha%20o%20produto%20:");

                        for (int i = 0; i < lstProd.size(); i++) {
                            b.enviarMensagem(Integer.toString(id_cliente), (Integer.toString(lstProd.get(i).getIdProduto()) + "%20"
                                    + lstProd.get(i).getDescricao() + "%20R$" + Double.toString(lstProd.get(i).getPreco())));
                        }

                        //Incrementa no contador para saber em qual parte do pedido está
                        controlador++;
                    } else {//Se não for uma categoria valida solicita outra
                        b.enviarMensagem(Integer.toString(id_cliente), "Categoria%20selecionado%20inccorreta,%20tente%20novamente:");
                    }
                    break;

                case 2:
                    int numProd = testaValorPassado(mensagem_recebida);
                    String numProd1 = Integer.toString(numProd);
                    //For para verificar qual o produto selecionado
                    for (int i = 0; i < lstProd.size(); i++) {
                        if (mensagem_recebida.contains(lstProd.get(i).getDescricao()) || mensagem_recebida.contains(Integer.toString(lstProd.get(i).getIdProduto()))) {
                            ehProduto = i + 1;
                        }else if (numProd1.contains(lstProd.get(i).getDescricao()) || numProd1.contains(Integer.toString(lstProd.get(i).getIdProduto()))) {
                            ehProduto = i + 1;
                        }
                    }

                    if (ehProduto != 0) {//Se for um produto existente

                        //Pede a quantidade deste produto
                        b.enviarMensagem(Integer.toString(id_cliente), "Digite%20a%20quantidade%20do%20produto%20escolhido:");

                        //Incrementa no contador para saber em qual parte do pedido está
                        controlador++;
                    } else {//Se for um produto invalido solicita outro
                        b.enviarMensagem(Integer.toString(id_cliente), "Produto%20selecionado%20incorreto,%20tente%20novamente:");
                    }
                    break;

                case 3:
                    //validação pra quantida, por exemplo se passou 1 ou um ou uma
                    quantidade = testaValorPassado(mensagem_recebida);

                    if (quantidade != 0) {//Se for uma quantidade valida

                        //Vai setar alguns dados do PedidoItem
                        pedido_item.setProduto_id(lstProd.get(ehProduto - 1).getIdProduto());
                        pedido_item.setQuantidade(quantidade);
                        pedido_item.setPreco(lstProd.get(ehProduto - 1).getPreco());

                        //verifica se quer adicionar observação
                        b.enviarMensagem(Integer.toString(id_cliente), "Gostaria%20de%20adicionar%20alguma%20observação?");
                        b.enviarMensagem(Integer.toString(id_cliente), "1%20Sim");
                        b.enviarMensagem(Integer.toString(id_cliente), "2%20Não");

                        //Incrementa no contador para saber em qual parte do pedido está
                        controlador++;
                    } else {//Caso não seja um quantidade valida solicita outra quantidade
                        b.enviarMensagem(Integer.toString(id_cliente), "Quantidade%20invalida,%20tente%20novamente:");
                    }
                    break;

                case 4:
                    //Se o cliente quiser adicionar uma observação
                    if (mensagem_recebida.equals("sim") || mensagem_recebida.equals("1")) {

                        //pede qual a observação deseja dizer
                        b.enviarMensagem(Integer.toString(id_cliente), "Digite%20sua%20observação:");

                        //variavel = true para add uma observação
                        boo = true;

                        //Incrementa no contador para saber em qual parte do pedido está
                        controlador++;
                    } else {//Se o cliente não quis adicionar uma observação
                        //Insere uma observação vazia para não deixar null
                        pedido_item.setObservacao("");

                        //variavel = false dizendo que não tem observaão a fazer
                        boo = false;

                        //Incrementa no contador para saber em qual parte do pedido está 
                        controlador++;

                        //Chamada do metodo novamente para continuar nos processos
                        responder(t, b);
                    }

                    break;

                case 5:
                    if (boo) { //adiciona a observação do usuário
                        pedido_item.setObservacao(mensagem_recebida);
                    }

                    //Mosta toda a informação do pedido do cliente
                    b.enviarMensagem(Integer.toString(id_cliente), ("Você%20pediu:%20" + quantidade + "%20" + lstCat.get(ehCategoria - 1).getDescricao() + "%20" + lstProd.get(ehProduto - 1).getDescricao() + "%20" + pedido_item.getObservacao() + "%20R$" + Double.toString(quantidade * pedido_item.getPreco())));

                    //verifica o que deseja fazer a mais
                    b.enviarMensagem(Integer.toString(id_cliente), "O%20que%20deseja%20fazer%20seguir?");
                    b.enviarMensagem(Integer.toString(id_cliente), "1%20Finalizar");
                    b.enviarMensagem(Integer.toString(id_cliente), "2%20Cancelar");
                    b.enviarMensagem(Integer.toString(id_cliente), "3%20Adicionar%20outro%20produto");

                    //Incrementa no contador para saber em qual parte do pedido está
                    controlador++;
                    break;

                case 6:

                    //Se o cliente so quiser finalizar o pedido
                    if (mensagem_recebida.equals("finalizar") || mensagem_recebida.equals("1")) {
                        //Seta as informações do pedido
                        //formata a data
                        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
                        Date parsedDate = dateFormat.parse(t.getData() + " " + t.getHora());
                        //passa pra timestamp
                        Timestamp timestamp = new java.sql.Timestamp(parsedDate.getTime());

                        pedido.setData(timestamp); //data do pedido e hora
                        pedido.setFinalizado(1); //seta como finaizado = 1
                        pedido.setEntregue(0); //ainda não foi entregue
                        pedido.setCliente_idCliente(id_cliente); //id do cliente que fez o pedido

                        dal.DAO daoPed = new dal.DAO();
                        if (addInfoSouN) {
                            //insere pedido
                            daoPed.inserir(pedido);
                            addInfoSouN = false;
                        }
                        //atualiza lista de pedidos
                        lstPed = daoPed.todosRegistros(Pedido.class, 0, 0);

                        //Procura o pedido para receber o ID de Pedido e inserir no PedidoItem
                        for (int i = 0; i < lstPed.size(); i++) {
                            if ((lstPed.get(i).getCliente_idCliente() == id_cliente)/* && (lstPed.get(i).getData() == /*timetimestamp)*/) {
                                pedido_item.setPedido_id(lstPed.get(i).getIdPedido());
                            }
                        }

                        //Insere o pedido item
                        daoPed.inserir(pedido_item);

                        //Reseta as informações depois de finalizado
                        controlador = 0;
                        pedido_item = new PedidoItem();
                        pedido = new Pedido();
                        ehCategoria = 0;
                        ehProduto = 0;
                        quantidade = 0;
                        addInfoSouN = true;

                        lstCat = new ArrayList<>();
                        lstProd = new ArrayList<>();
                        lstPed = new ArrayList<>();

                        //Avisa o usuário que o pedido foi finalizado com sucesso
                        b.enviarMensagem(Integer.toString(id_cliente), "Pedido%20Finalizado!");

                    } else if (mensagem_recebida.equals("Cancelar") || mensagem_recebida.equals("2")) {
                        //cancela o pedido e reinicia todas as variáveis e não salva no banco
                        //Reseta as informações
                        controlador = 0;
                        pedido_item = new PedidoItem();
                        pedido = new Pedido();
                        ehCategoria = 0;
                        ehProduto = 0;
                        quantidade = 0;
                        addInfoSouN = true;

                        lstCat = new ArrayList<>();
                        lstProd = new ArrayList<>();
                        lstPed = new ArrayList<>();

                        //Informa que o pedido foi cancelado
                        b.enviarMensagem(Integer.toString(id_cliente), "Pedido%20Cancelado!");

                    } else if (mensagem_recebida.equals("adicionar produto") || mensagem_recebida.equals("3")) {
                        //Seta as informações do pedido
                        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
                        Date parsedDate = dateFormat.parse(t.getData() + " " + t.getHora());
                        Timestamp timestamp = new java.sql.Timestamp(parsedDate.getTime());
                        pedido.setData(timestamp);
                        pedido.setFinalizado(1);
                        pedido.setEntregue(0);
                        pedido.setCliente_idCliente(id_cliente);

                        dal.DAO daoPed = new dal.DAO();
                        if (addInfoSouN) {
                            //insere pedido
                            daoPed.inserir(pedido);
                            addInfoSouN = false;
                        }
                        lstPed = daoPed.todosRegistros(Pedido.class, 0, 0);

                        //Procura o pedido para receber o ID de Pedido e inserir no PedidoItem
                        for (int i = 0; i < lstPed.size(); i++) {
                            if ((lstPed.get(i).getCliente_idCliente() == id_cliente)/* && (lstPed.get(i).getData() == time)*/) {
                                pedido_item.setPedido_id(lstPed.get(i).getIdPedido());
                            }
                        }
                        //Insere o pedido item
                        daoPed.inserir(pedido_item);

                        //Envia o contador direto para o processo seguinte
                        controlador = 7;
                        //Chamada do metodo novamente para continuar nos processos
                        responder(t, b);

                    } else {//Caso o cliente escolha uma opção invalida é solicitado outra opção
                        b.enviarMensagem(Integer.toString(id_cliente), "Opção%20invalida,%20tente%20novamente:");
                    }

                    break;

                case 7:
                    //adiconar masi um pedido fara com que todo o proccesso seja feito novamente
                    //Envia a mensagem padrão das categorias
                    b.enviarMensagem(Integer.toString(id_cliente), "Escolha%20a%20categoria%20desejada:");

                    //Enviar outras mensagens contendo as categorias
                    for (int i = 0; i < lstCat.size(); i++) {
                        b.enviarMensagem(Integer.toString(id_cliente), (Integer.toString(lstCat.get(i).getIdCategoria()) + "%20" + lstCat.get(i).getDescricao()));
                    }
                    //controlador volta pro começo
                    controlador = 1;
                    break;
            }

        } catch (ClassNotFoundException ex) {
            Logger.getLogger(DialagoThread.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public int getCliId() {
        return id_cliente;
    }

    //conversão de valores
    private int testaValorPassado(String s) {
        try {
            //verica se é um numero, caso não seja verifica a string e passa ela pro número correspondente
            return Integer.parseInt(s);
        } catch (NumberFormatException ex) {
            switch (s) {
                case "um":
                    return 1;
                case "Um":
                    return 1;
                case "uma":
                    return 1;
                case "Uma":
                    return 1;
                case "dois":
                    return 2;
                case "Dois":
                    return 2;
                case "duas":
                    return 2;
                case "Duas":
                    return 2;
                case "tres":
                    return 3;
                case "Tres":
                    return 3;
                case "três":
                    return 3;
                case "Três":
                    return 3;
                case "quatro":
                    return 4;
                case "Quatro":
                    return 4;
                case "cinco":
                    return 5;
                case "Cinco":
                    return 5;
                case "seis":
                    return 6;
                case "Seis":
                    return 6;
                case "sete":
                    return 7;
                case "Sete":
                    return 7;
                case "oito":
                    return 8;
                case "Oito":
                    return 8;
                case "nove":
                    return 9;
                case "Nove":
                    return 9;
                case "dez":
                    return 10;
                case "Dez":
                    return 10;
                case "onze":
                    return 11;
                case "Onze":
                    return 11;
                case "doze":
                    return 12;
                case "Doze":
                    return 12;
                case "treze":
                    return 13;
                case "Treze":
                    return 13;
                case "catorze":
                    return 14;
                case "Catorze":
                    return 14;
                case "quatorze":
                    return 14;
                case "Quatorze":
                    return 14;
                case "quinze":
                    return 15;
                case "Quinze":
                    return 15;
                default:
                    return 0;
            }
        }
    }


}
